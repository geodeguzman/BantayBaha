<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../includes/dbconnection.php';
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message']);
    // Get admin ID from database using username
    $admin_username = $_SESSION['admin_username'];
    $stmt = $dbh->prepare('SELECT id FROM admin_users WHERE username = :username');
    $stmt->execute([':username' => $admin_username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        $error = 'Admin user not found.';
    } else {
        $created_by = $admin['id'];
    if (strlen($message) < 3) {
        $error = 'Announcement must be at least 3 characters.';
    } else {
        try {
            $stmt = $dbh->prepare('INSERT INTO announcements (message, created_by) VALUES (:message, :created_by)');
            $stmt->execute([
                ':message' => $message,
                ':created_by' => $created_by
            ]);
            $success = 'Announcement sent!';
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
    }
}

// Fetch past announcements
try {
    $stmt = $dbh->prepare('SELECT a.*, au.username as admin_username FROM announcements a JOIN admin_users au ON a.created_by = au.id ORDER BY a.created_at DESC LIMIT 10');
    $stmt->execute();
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $announcements = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create Announcement</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        body { 
            background: url('../img/bucal.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0; 
            font-family: 'Segoe UI', Arial, sans-serif; 
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
            pointer-events: none;
        }
        .admin-layout { 
            display: flex; 
            min-height: 100vh; 
            position: relative;
            z-index: 1;
        }
        .sidebar { 
            width: 220px; 
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1.5px solid #e3eafc; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            padding: 30px 0 0 0; 
        }
        .sidebar .logo-placeholder { 
            width: 120px; 
            height: 120px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-bottom: 30px; 
        }
        .nav-btn { 
            width: 170px; 
            background: #f7fafd; 
            border: 1.5px solid #e3eafc; 
            border-radius: 12px; 
            padding: 12px 0; 
            margin-bottom: 18px; 
            font-size: 1.1rem; 
            color: #222; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            justify-content: left; 
            font-weight: 500; 
            transition: background 0.2s, color 0.2s; 
        }
        .nav-btn.active, .nav-btn:hover { 
            background: #e3eafc; 
            color: #1565c0; 
        }
        .logout-btn { 
            margin-top: auto; 
            margin-bottom: 30px; 
            background: #fff; 
            color: #e53935; 
            border: 1.5px solid #e53935; 
            border-radius: 12px; 
            padding: 10px 0; 
            width: 170px; 
            font-weight: 600; 
            transition: background 0.2s, color 0.2s; 
        }
        .logout-btn:hover { 
            background: #e53935; 
            color: #fff; 
        }
        .main-content { 
            flex: 1; 
            padding: 30px; 
            display: flex; 
            flex-direction: column; 
            gap: 30px; 
        }
        .card {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 18px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            padding: 28px 32px; 
            margin-bottom: 20px; 
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .title { 
            font-size: 1.8rem; 
            font-weight: 600; 
            color: #1565c0; 
            margin-bottom: 24px; 
            text-align: center; 
        }
        .form-control { 
            border-radius: 12px; 
            border: 1.5px solid #e3eafc; 
            padding: 12px 16px; 
            background: rgba(255, 255, 255, 0.9);
            transition: border-color 0.2s;
        }
        .form-control:focus {
            border-color: #1565c0;
            box-shadow: 0 0 0 3px rgba(21, 101, 192, 0.1);
        }
        .btn-primary { 
            border-radius: 12px; 
            font-weight: 600; 
            padding: 12px 28px; 
            background: #1565c0;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary:hover {
            background: #0d47a1;
            transform: translateY(-1px);
        }
        .error-msg { 
            color: #e53935; 
            margin-bottom: 12px; 
            text-align: center; 
            font-weight: 600;
        }
        .success-msg { 
            color: #43a047; 
            margin-bottom: 12px; 
            text-align: center; 
            font-weight: 600;
        }
        .announcement-list { 
            margin-top: 12px; 
        }
        .announcement-item { 
            background: rgba(227, 234, 252, 0.8); 
            border-radius: 12px; 
            padding: 16px 20px; 
            margin-bottom: 16px; 
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: transform 0.2s;
        }
        .announcement-item:hover {
            transform: translateY(-2px);
        }
        .announcement-meta { 
            font-size: 0.95rem; 
            color: #1565c0; 
            margin-bottom: 8px; 
            font-weight: 600;
        }
        .announcement-message { 
            font-size: 1.1rem; 
            line-height: 1.5;
            color: #333;
        }
        @media (max-width: 900px) { 
            .main-content { padding: 20px 5px; } 
            .sidebar { width: 60px; padding: 0 10px; } 
            .nav-btn, .logout-btn { width: 60px; padding: 8px 0; font-size: 0.9rem; margin-bottom: 0; margin-right: 8px; justify-content: center; } 
            .sidebar .logo-placeholder { width: 60px; height: 60px; border-radius: 0 0 30px 30px/0 0 30px 30px; font-size: 1rem; margin-bottom: 0; } 
        }
    </style>
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="logo-placeholder"><img src="../img/Logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;"></div>
        <div style="margin-bottom: 18px; color: #1565c0; font-weight: 600; text-align: center;">
            <?php if (isset($_SESSION['admin_name'])): ?>
                <div style="font-size: 1.05rem;">Welcome,<br><?php echo htmlspecialchars($_SESSION['admin_name']); ?></div>
            <?php endif; ?>
        </div>
        <a class="nav-btn" href="dashboard.php"><i class="fa fa-columns"></i> Dashboard</a>
        <a class="nav-btn" href="reports.php"><i class="fa fa-file-alt"></i> Reports</a>
        <a class="nav-btn" href="map.php"><i class="fa fa-map"></i> Map</a>
        <a class="nav-btn" href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a class="nav-btn active" href="announcement.php"><i class="fa fa-bullhorn"></i> Create Announcement</a>
        <a class="logout-btn" href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
    </aside>
    <main class="main-content">
        <div class="card">
            <div class="title">Create Announcement</div>
            <?php if ($error): ?>
                <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
            <?php elseif ($success): ?>
                <div class="success-msg"><?php echo $success; ?></div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <div class="mb-3">
                    <label for="message" class="form-label">Announcement</label>
                    <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100">Send Announcement</button>
            </form>
        </div>
        <div class="card announcement-list">
            <div style="font-weight:600; color:#1565c0; margin-bottom:10px;">Recent Announcements</div>
            <?php foreach ($announcements as $a): ?>
                <div class="announcement-item">
                    <div class="announcement-meta">
                        <?php echo htmlspecialchars($a['admin_username']); ?> &bull; <?php echo date('M d, Y H:i', strtotime($a['created_at'])); ?>
                    </div>
                    <div class="announcement-message"><?php echo nl2br(htmlspecialchars($a['message'])); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
</div>
</body>
</html> 