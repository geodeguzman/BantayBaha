<?php
session_start();
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require_once '../includes/dbconnection.php';

try {
    $lastTimestamp = $_GET['last_timestamp'] ?? '';
    
    // Get latest report timestamp
    $stmt = $dbh->prepare("SELECT MAX(created_at) as latest FROM flood_reports");
    $stmt->execute();
    $latestTimestamp = $stmt->fetch(PDO::FETCH_ASSOC)['latest'];
    
    // Check if there are new reports
    $hasNewReports = false;
    if ($lastTimestamp && $latestTimestamp) {
        $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports WHERE created_at > ?");
        $stmt->execute([$lastTimestamp]);
        $newCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        $hasNewReports = $newCount > 0;
    }
    
    // Get unread count (reports created since last visit)
    $lastVisit = $_SESSION['last_reports_visit'] ?? null;
    
    if ($lastVisit) {
        $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports WHERE created_at > ?");
        $stmt->execute([$lastVisit]);
    } else {
        // If no last visit, show reports from last 24 hours
        $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stmt->execute();
    }
    $unreadCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo json_encode([
        'hasNewReports' => $hasNewReports,
        'unreadCount' => $unreadCount,
        'latestTimestamp' => $latestTimestamp
    ]);
    
} catch (PDOException $e) {
    error_log("Database error in check_new_reports.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?> 