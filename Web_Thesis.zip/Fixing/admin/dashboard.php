<?php 
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Handle logout
if(isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Include database connection
require_once '../includes/dbconnection.php';

// Function to get water level data for the last 24 hours
function getWaterLevelData($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        // Fetch all readings from the last 24 hours from the real table
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            WHERE waterLevel_Timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY waterLevel_Timestamp ASC
        ");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group by hour and average, but preserve threshold information
        $hourly = [];
        foreach ($rows as $row) {
            $dt = new DateTime($row['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila')); // Convert to Philippine time
            $hourKey = $dt->format('Y-m-d H:00:00');
            if (!isset($hourly[$hourKey])) {
                $hourly[$hourKey] = [
                    'sum' => 0, 
                    'count' => 0, 
                    'timestamp' => $hourKey,
                    'thresholds' => [],
                    'feet_sum' => 0
                ];
            }
            $hourly[$hourKey]['sum'] += floatval($row['waterLevel_Reading_CM']) / 100.0;
            $hourly[$hourKey]['feet_sum'] += floatval($row['waterLevel_Reading_Feet']);
            $hourly[$hourKey]['count']++;
            $hourly[$hourKey]['thresholds'][] = $row['waterLevel_Threshold'];
        }
        $result = [];
        foreach ($hourly as $hour) {
            $avg = $hour['sum'] / $hour['count'];
            $avgFeet = $hour['feet_sum'] / $hour['count'];
            
            // Determine the most common threshold for this hour
            $thresholdCounts = array_count_values($hour['thresholds']);
            $mostCommonThreshold = array_keys($thresholdCounts, max($thresholdCounts))[0];
            
            $result[] = [
                'water_level_meters' => $avg,
                'water_level_feet' => $avgFeet,
                'threshold' => $mostCommonThreshold,
                'timestamp' => $hour['timestamp'],
                'sensor_id' => 'real'
            ];
        }
        // If more than 24, keep only the last 24
        if (count($result) > 24) {
            $result = array_slice($result, -24);
        }
        return $result;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

// Function to get current water level
function getCurrentWaterLevel($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            ORDER BY waterLevel_Timestamp DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $meters = floatval($result['waterLevel_Reading_CM']) / 100.0;
            $feet = floatval($result['waterLevel_Reading_Feet']);
            $threshold = $result['waterLevel_Threshold'];
            
            // Convert timestamp to Philippine time
            $dt = new DateTime($result['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila'));
            
            return [
                'level' => $meters,
                'feet' => $feet,
                'threshold' => $threshold,
                'timestamp' => $dt->format('Y-m-d H:i:s')
            ];
        }
        return ['level' => 0.899, 'feet' => 2.95, 'threshold' => 'normal', 'timestamp' => date('Y-m-d H:i:s')]; // Default fallback
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['level' => 0.899, 'feet' => 2.95, 'threshold' => 'normal', 'timestamp' => date('Y-m-d H:i:s')];
    }
}

// Get data for the page
$waterLevelData = getWaterLevelData($dbh);
$currentWaterLevel = getCurrentWaterLevel($dbh);

// Convert to JSON for JavaScript
$waterLevelJson = json_encode($waterLevelData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Thesis Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        body {
            background: url('../img/bucal.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4); /* Dark overlay for better readability */
            z-index: 0;
            pointer-events: none;
        }
        .admin-layout {
            display: flex;
            min-height: 100vh;
            position: relative;
            z-index: 1;
        }
        .sidebar {
            width: 220px;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px); /* Safari support */
            border-right: 1.5px solid #e3eafc;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 30px 0 0 0;
            position: relative;
        }
        /* Fallback for browsers that don't support backdrop-filter */
        @supports not (backdrop-filter: blur(10px)) {
            .sidebar {
                background: rgba(255, 255, 255, 0.75);
            }
        }
        .sidebar .logo-placeholder {
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
            animation: popin 1s cubic-bezier(.68,-0.55,.27,1.55);
        }
        @keyframes popin {
            0% { transform: scale(0.7); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        .nav-btn {
            width: 170px;
            background: #f7fafd;
            border: 1.5px solid #e3eafc;
            border-radius: 12px;
            padding: 12px 0;
            margin-bottom: 18px;
            font-size: 1.1rem;
            color: #222;
            display: flex;
            align-items: center;
            gap: 12px;
            justify-content: left;
            font-weight: 500;
            transition: background 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s;
            position: relative;
            overflow: hidden;
        }
        .nav-btn.active, .nav-btn:hover {
            background: #e3eafc;
            color: #1565c0;
            box-shadow: 0 2px 12px rgba(33,150,243,0.08);
            transform: translateX(4px) scale(1.04);
        }
        .nav-btn.active::before {
            content: '';
            position: absolute;
            left: 0; top: 0; bottom: 0;
            width: 5px;
            background: linear-gradient(180deg, #2196f3 0%, #1565c0 100%);
            border-radius: 5px 0 0 5px;
            animation: slidein 0.5s;
        }
        @keyframes slidein {
            from { width: 0; }
            to { width: 5px; }
        }
        .logout-btn {
            margin-top: auto;
            margin-bottom: 30px;
            background: rgba(255, 255, 255, 0.7);
            color: #e53935;
            border: 1.5px solid #e53935;
            border-radius: 12px;
            padding: 10px 0;
            width: 170px;
            font-weight: 600;
            transition: background 0.2s, color 0.2s, box-shadow 0.2s;
        }
        .logout-btn:hover {
            background: #e53935;
            color: #fff;
            box-shadow: 0 2px 12px rgba(229,57,53,0.08);
        }
        .main-content {
            flex: 1;
            padding: 40px 30px 30px 30px;
            display: flex;
            flex-direction: column;
            gap: 30px;
            position: relative;
            z-index: 1;
        }
        .card {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px); /* Safari support */
            border-radius: 18px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 24px 28px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            opacity: 0;
            transform: translateY(30px);
            animation: fadein 0.8s cubic-bezier(.68,-0.55,.27,1.55) forwards;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        /* Fallback for browsers that don't support backdrop-filter */
        @supports not (backdrop-filter: blur(10px)) {
            .card {
                background: rgba(255, 255, 255, 0.7);
            }
        }
        .card:nth-child(1) { animation-delay: 0.1s; }
        .card:nth-child(2) { animation-delay: 0.2s; }
        .card:nth-child(3) { animation-delay: 0.3s; }
        .card:nth-child(4) { animation-delay: 0.4s; }
        @keyframes fadein {
            to { opacity: 1; transform: none; }
        }
        .chart-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 18px;
            color: #1565c0;
            letter-spacing: 0.5px;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1.2fr;
            grid-template-rows: 320px;
            gap: 24px;
        }
        .btn, .btn-primary {
            transition: background 0.2s, color 0.2s, box-shadow 0.2s, transform 0.2s;
        }
        .btn-primary:hover, .btn:hover {
            box-shadow: 0 2px 12px rgba(33,150,243,0.10);
            transform: scale(1.04);
        }
        /* Weather icon animation */
        .weather-anim {
            display: inline-block;
            vertical-align: middle;
            margin-right: 10px;
            font-size: 2.2rem;
            animation: weatherfloat 2s ease-in-out infinite alternate;
        }
        @keyframes weatherfloat {
            0% { transform: translateY(0); }
            100% { transform: translateY(-8px); }
        }
        .water-level {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            height: 100%;
            padding-top: 20px;
        }
        .water-gauge {
            width: 60px;
            height: 220px;
            background: linear-gradient(180deg, #e3eafc 0%, #2196f3 100%);
            border-radius: 30px;
            position: relative;
            margin-bottom: 18px;
        }
        .water-gauge-fill {
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 90px;
            background: linear-gradient(180deg, #2196f3 0%, #1565c0 100%);
            border-radius: 0 0 30px 30px;
            transition: height 0.5s ease, background 0.5s ease;
        }
        .water-level-info {
            margin-top: 25px;
            font-size: 0.95rem;
            text-align: center;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
            width: 100%;
        }
        .water-level-info.normal {
            color: #ffffff;
            background: rgba(0, 0, 0, 0.9);
            border: 3px solid #43a047;
            animation: pulse 1.5s infinite;
            font-weight: bold;
            font-size: 1.1rem;
            padding: 15px;
            margin-top: 20px;
            box-shadow: 0 6px 20px rgba(67, 160, 71, 0.5);
            text-align: center;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        .water-level-info.warning {
            color: #ffffff;
            background: rgba(0, 0, 0, 0.9);
            border: 3px solid #fbc02d;
            animation: pulse 1.5s infinite;
            font-weight: bold;
            font-size: 1.1rem;
            padding: 15px;
            margin-top: 20px;
            box-shadow: 0 6px 20px rgba(251, 192, 45, 0.5);
            text-align: center;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        .water-level-info.danger {
            color: #ffffff;
            background: rgba(0, 0, 0, 0.9);
            border: 3px solid #e53935;
            animation: pulse 1.5s infinite;
            font-weight: bold;
            font-size: 1.1rem;
            padding: 15px;
            margin-top: 20px;
            box-shadow: 0 6px 20px rgba(229, 57, 53, 0.5);
            text-align: center;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        @keyframes pulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.02); }
            100% { opacity: 1; transform: scale(1); }
        }
        .water-gauge-labels {
            position: absolute;
            left: 70px;
            top: 0;
            height: 220px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            font-size: 0.95rem;
            color: #1565c0;
            pointer-events: none;
            width: 60px;
            z-index: 2;
        }
        .water-gauge-labels div {
            margin: 0;
            padding: 0 2px;
            text-align: left;
            background: rgba(255,255,255,0.7);
            border-radius: 4px;
            font-size: 0.93rem;
            line-height: 1.1;
        }
        .residents-help {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .resident-card {
            background: rgba(227, 234, 252, 0.6);
            backdrop-filter: blur(5px);
            border-radius: 12px;
            padding: 12px 18px;
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .resident-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #2196f3;
            font-weight: bold;
        }
        .resident-info {
            flex: 1;
        }
        .pie-chart-placeholder {
            width: 100%;
            height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .chart-container {
            width: 100%;
            height: 200px;
            position: relative;
        }
        .chart-bars {
            display: flex;
            align-items: end;
            justify-content: space-between;
            height: 100%;
            padding: 10px 0;
        }
        .chart-bar {
            flex: 1;
            background: #1565c0;
            margin: 0 2px;
            border-radius: 2px 2px 0 0;
            transition: height 0.3s ease;
            position: relative;
        }
        .chart-bar:hover {
            background: #0d47a1;
        }
        .chart-labels {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 0.8rem;
            color: #1565c0;
        }
        .data-source-indicator {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255, 255, 255, 0.9);
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            color: #666;
        }
        @media (max-width: 1100px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
                grid-template-rows: repeat(2, 320px);
            }
        }
        @media (max-width: 700px) {
            .admin-layout {
                flex-direction: column;
            }
            .sidebar {
                flex-direction: row;
                width: 100vw;
                height: 80px;
                border-right: none;
                border-bottom: 1.5px solid #e3eafc;
                padding: 0 10px;
                align-items: center;
                justify-content: space-between;
            }
            .sidebar .logo-placeholder {
                width: 60px;
                height: 60px;
                border-radius: 0 0 30px 30px/0 0 30px 30px;
                font-size: 1rem;
                margin-bottom: 0;
            }
            .nav-btn, .logout-btn {
                width: 60px;
                padding: 8px 0;
                font-size: 0.9rem;
                margin-bottom: 0;
                margin-right: 8px;
                justify-content: center;
            }
            .main-content {
                padding: 20px 5px;
            }
        }
        /* Update the summary section CSS for better wrapping and spacing */
        #waterLevelSummary {
            margin-top: 18px;
            background: rgba(247, 250, 253, 0.6);
            backdrop-filter: blur(5px);
            border-radius: 12px;
            padding: 14px 18px;
            box-shadow: 0 1px 4px rgba(44,62,80,0.07);
            font-size: 1rem;
            color: #1565c0;
            display: flex;
            flex-wrap: wrap;
            gap: 18px;
            align-items: center;
            justify-content: flex-start;
        }
        #waterLevelSummary > div {
            min-width: 160px;
            margin-bottom: 6px;
        }
        @media (max-width: 700px) {
            #waterLevelSummary {
                flex-direction: column;
                align-items: flex-start;
                gap: 8px;
            }
            #waterLevelSummary > div {
                min-width: 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>
<script>
window.addEventListener('pageshow', function(event) {
  if (event.persisted) {
    window.location.reload();
  }
});
</script>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="logo-placeholder"><img src="../img/Logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;"></div>
        <div style="margin-bottom: 18px; color: #1565c0; font-weight: 600; text-align: center;">
            <?php if (isset($_SESSION['admin_name'])): ?>
                <div style="font-size: 1.05rem;">Welcome,<br><?php echo htmlspecialchars($_SESSION['admin_name']); ?></div>
            <?php endif; ?>
        </div>
        <a class="nav-btn" href="dashboard.php"><i class="fa fa-columns"></i> Dashboard</a>
        <a class="nav-btn" href="reports.php"><i class="fa fa-file-alt"></i> Reports</a>
        <a class="nav-btn" href="map.php"><i class="fa fa-map"></i> Map</a>
        <a class="nav-btn" href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a class="nav-btn" href="announcement.php"><i class="fa fa-bullhorn"></i> Create Announcement</a>
        <a class="logout-btn" href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
    </aside>
    <main class="main-content">
        <div class="row" style="gap: 24px; margin-bottom: 10px;">
            <div class="col-md-6 col-lg-4" style="margin-bottom: 18px;">
                <div class="card" id="weatherCard" style="min-height: 120px; display: flex; flex-direction: column; align-items: flex-start;">
                    <div class="chart-title" style="margin-bottom: 8px;">Current Weather</div>
                    <div id="weatherInfo">Loading weather...</div>
                </div>
            </div>
            <div class="col-md-6 col-lg-4" style="margin-bottom: 18px;">
                <div class="card" id="rainCard" style="min-height: 120px; display: flex; flex-direction: column; align-items: flex-start;">
                    <div class="chart-title" style="margin-bottom: 8px;">Rain Volume (Last 1h)</div>
                    <div id="rainInfo">Loading rain data...</div>
                </div>
            </div>
        </div>
        <div class="dashboard-grid">
            <!-- 24 Hour Water Level Chart -->
            <!-- Move the legend above the chart card, outside the card for better aesthetics -->
            <div style="width:100%; display:flex; justify-content:flex-end; margin-bottom: 10px;">
                <div style="background: rgba(255,255,255,0.95); border-radius: 8px; padding: 4px 16px; font-size: 0.95rem; box-shadow: 0 1px 4px rgba(44,62,80,0.07); display: flex; align-items: center; gap: 18px;">
                    <span style="display:inline-block;width:18px;height:12px;background:#1565c0;border-radius:2px;margin-right:4px;"></span>Normal
                    <span style="display:inline-block;width:18px;height:12px;background:#fbc02d;border-radius:2px;margin:0 4px 0 12px;"></span>Warning
                    <span style="display:inline-block;width:18px;height:12px;background:#e53935;border-radius:2px;margin:0 4px 0 12px;"></span>Danger
                </div>
            </div>
            <!-- Chart Card -->
            <div class="card" style="grid-column: 1; grid-row: 1; position: relative;">
                <div class="chart-title">24 Hour Water Level Chart</div>
                <div class="data-source-indicator" id="dataSourceIndicator">Placeholder Data</div>
                <div class="chart-container" style="position: relative;">
                    <!-- Y-axis label moved further left -->
                    <div style="position: absolute; left: -75px; top: 50%; transform: translateY(-50%) rotate(-90deg); font-size: 0.95rem; color: #1565c0; font-weight: 600; letter-spacing: 0.5px;">Water Level (meters)</div>
                    <div class="chart-bars" id="waterLevelChart">
                        <!-- Chart bars will be generated by JavaScript -->
                    </div>
                    <div class="chart-labels">
                        <span>24h ago</span>
                        <span>12h ago</span>
                        <span>Now</span>
                    </div>
                </div>
                <!-- X-axis label moved further down for spacing -->
                <div style="text-align: center; margin: 32px 0 8px 0; font-size: 0.95rem; color: #1565c0; font-weight: 600; letter-spacing: 0.5px;">Time (past 24 hours)</div>
                <!-- Summary Section Below Chart -->
                <div id="waterLevelSummary" style="margin-top: 0; background: #f7fafd; border-radius: 12px; padding: 14px 18px; box-shadow: 0 1px 4px rgba(44,62,80,0.07); font-size: 1rem; color: #1565c0; display: flex; flex-wrap: wrap; gap: 18px; align-items: center; justify-content: space-between;"></div>
            </div>
            <!-- Water Level -->
            <div class="card" style="grid-column: 2; grid-row: 1; align-items: center;">
                <div class="chart-title" id="currentWaterLevel">Loading...</div>
                <div class="water-level">
                    <div style="position: relative;">
                        <div class="water-gauge">
                            <div class="water-gauge-fill" id="waterGaugeFill"></div>
                        </div>
                        <div class="water-gauge-labels" style="left: 70px; top: 0; position: absolute; height: 220px;">
                            <div>8 Feet</div>
                            <div>6 Feet</div>
                            <div>4 Feet</div>
                            <div>2 Feet</div>
                            <div>0 Feet</div>
                        </div>
                    </div>
                    <div class="water-level-info normal" id="waterLevelInfo">
                        Loading water level information...
                    </div>
                </div>
            </div>


        </div>
    </main>
</div>

<script>
// Water level data from PHP
const waterLevelData = <?php echo $waterLevelJson; ?>;
const currentWaterLevel = <?php echo json_encode($currentWaterLevel); ?>;

// Function to convert meters to feet
function metersToFeet(meters) {
    return meters * 3.28084;
}

// Function to format water level display
function formatWaterLevel(meters) {
    const feet = metersToFeet(meters);
    const feetInt = Math.floor(feet);
    const inches = Math.round((feet - feetInt) * 12);
    return `${feetInt}'${inches.toString().padStart(2, '0')}" (${meters.toFixed(3)} Meters)`;
}

// Function to calculate water level trend and rate of change
function calculateTrend(data) {
    if (data.length < 2) return { trend: 'stable', rate: 0 };
    
    const recent = data.slice(-3); // Last 3 readings
    const older = data.slice(-6, -3); // 3 readings before that
    
    if (recent.length < 3 || older.length < 3) {
        return { trend: 'stable', rate: 0 };
    }
    
    const recentAvg = recent.reduce((sum, item) => sum + parseFloat(item.water_level_meters), 0) / recent.length;
    const olderAvg = older.reduce((sum, item) => sum + parseFloat(item.water_level_meters), 0) / older.length;
    
    const change = recentAvg - olderAvg;
    
    // Calculate rate of change per minute (assuming readings are hourly)
    const timeDiffHours = 3; // 3 hours between older and recent averages
    const ratePerMinute = change / (timeDiffHours * 60);
    
    if (Math.abs(change) < 0.01) return { trend: 'stable', rate: 0 };
    return { 
        trend: change > 0 ? 'rising' : 'falling',
        rate: Math.abs(ratePerMinute)
    };
}

// Function to generate chart bars
function generateChart() {
    const chartContainer = document.getElementById('waterLevelChart');
    chartContainer.innerHTML = '';
    
    if (waterLevelData.length === 0) {
        chartContainer.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">No data available</div>';
        return;
    }
    
    // Find min and max values for scaling
    const levels = waterLevelData.map(item => parseFloat(item.water_level_meters));
    const minLevel = Math.min(...levels);
    const maxLevel = Math.max(...levels);
    const range = maxLevel - minLevel || 1; // Prevent division by zero
    
    waterLevelData.forEach((item, index) => {
        const level = parseFloat(item.water_level_meters);
        const height = ((level - minLevel) / range) * 100;
        
        const bar = document.createElement('div');
        bar.className = 'chart-bar';
        bar.style.height = `${Math.max(height, 5)}%`; // Minimum 5% height for visibility
        
        // Color logic based on historical water level threshold from database
        const historicalThreshold = item.threshold ? item.threshold.toLowerCase() : 'normal';
        
        if (historicalThreshold === 'danger') {
            bar.style.background = 'linear-gradient(180deg, #e53935 0%, #c62828 100%)'; // Red
        } else if (historicalThreshold === 'caution') {
            bar.style.background = 'linear-gradient(180deg, #fbc02d 0%, #f57f17 100%)'; // Orange
        } else {
            bar.style.background = 'linear-gradient(180deg, #2196f3 0%, #1565c0 100%)'; // Blue
        }
        // Convert to Philippine time for display
        const phTime = new Date(item.timestamp + ' Asia/Manila');
        const feet = item.water_level_feet ? parseFloat(item.water_level_feet).toFixed(2) : metersToFeet(level).toFixed(2);
        bar.title = `${feet} feet (${level.toFixed(3)} meters) - ${historicalThreshold.toUpperCase()} at ${phTime.toLocaleTimeString('en-US', {timeZone: 'Asia/Manila'})}`;
        
        chartContainer.appendChild(bar);
    });
}

// Function to update water gauge
function updateWaterGauge() {
    const gaugeFill = document.getElementById('waterGaugeFill');
    const currentLevel = parseFloat(currentWaterLevel.level);
    
    // Convert to percentage (assuming max water level is 2.5 meters = 8 feet)
    const maxLevel = 2.5;
    const percentage = Math.min((currentLevel / maxLevel) * 100, 100);
    
    // Update gauge fill with smooth animation
    gaugeFill.style.height = `${percentage}%`;
    
    // Update gauge color based on water level threshold from database
    const currentThreshold = currentWaterLevel.threshold ? currentWaterLevel.threshold.toLowerCase() : 'normal';
    
    if (currentThreshold === 'danger') {
        gaugeFill.style.background = 'linear-gradient(180deg, #e53935 0%, #c62828 100%)'; // Red
    } else if (currentThreshold === 'caution') {
        gaugeFill.style.background = 'linear-gradient(180deg, #fbc02d 0%, #f57f17 100%)'; // Orange
    } else {
        gaugeFill.style.background = 'linear-gradient(180deg, #2196f3 0%, #1565c0 100%)'; // Blue
    }
}

// Function to update water level info
function updateWaterLevelInfo() {
    const currentLevel = parseFloat(currentWaterLevel.level);
    const currentFeet = parseFloat(currentWaterLevel.feet);
    const currentThreshold = currentWaterLevel.threshold ? currentWaterLevel.threshold.toLowerCase() : 'normal';
    const trendData = calculateTrend(waterLevelData);
    
    let infoText = '';
    let alertClass = '';
    
    if (currentThreshold === 'danger') {
        infoText = `<strong style="color: #e53935;">DANGER: Water level is at dangerous levels!</strong><br>`;
        infoText += `Current level: ${currentFeet.toFixed(2)} feet (${currentLevel.toFixed(3)} meters)<br>`;
        infoText += `Threshold: ${currentThreshold.toUpperCase()}<br>`;
        infoText += `Trend: ${trendData.trend} at ${trendData.rate.toFixed(4)} m/min`;
        alertClass = 'danger';
    } else if (currentThreshold === 'caution') {
        infoText = `<strong style="color: #fbc02d;">WARNING: Water level is elevated!</strong><br>`;
        infoText += `Current level: ${currentFeet.toFixed(2)} feet (${currentLevel.toFixed(3)} meters)<br>`;
        infoText += `Threshold: ${currentThreshold.toUpperCase()}<br>`;
        infoText += `Trend: ${trendData.trend} at ${trendData.rate.toFixed(4)} m/min`;
        alertClass = 'warning';
    } else {
        infoText = `<strong style="color: #43a047;">NORMAL: Water level is within safe limits</strong><br>`;
        infoText += `Current level: ${currentFeet.toFixed(2)} feet (${currentLevel.toFixed(3)} meters)<br>`;
        infoText += `Threshold: ${currentThreshold.toUpperCase()}<br>`;
        infoText += `Trend: ${trendData.trend} at ${trendData.rate.toFixed(4)} m/min`;
        alertClass = 'normal';
    }
    
    const infoElement = document.getElementById('waterLevelInfo');
    if (infoElement) {
        infoElement.innerHTML = infoText;
        infoElement.className = `water-level-info ${alertClass}`;
    }
}

// Function to update weather data
function updateWeatherData() {
    const weatherInfo = document.getElementById('weatherInfo');
    if (weatherInfo) {
        // Simulate weather data - in real implementation, fetch from weather API
        const weatherData = {
            temperature: 28,
            condition: 'Partly Cloudy',
            humidity: 75,
            windSpeed: 12,
            icon: 'fa-cloud-sun'
        };
        
        weatherInfo.innerHTML = `
            <div style="display: flex; align-items: center; margin-bottom: 10px;">
                <i class="fa ${weatherData.icon} weather-anim" style="color: #fbc02d;"></i>
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: #1565c0;">${weatherData.temperature}°C</div>
                    <div style="color: #666; font-size: 0.9rem;">${weatherData.condition}</div>
                </div>
            </div>
            <div style="font-size: 0.85rem; color: #666;">
                <div><i class="fa fa-tint"></i> Humidity: ${weatherData.humidity}%</div>
                <div><i class="fa fa-wind"></i> Wind: ${weatherData.windSpeed} km/h</div>
            </div>
        `;
    }
}

// Function to update rain volume data
function updateRainData() {
    const rainInfo = document.getElementById('rainInfo');
    if (rainInfo) {
        // Simulate rain data - in real implementation, fetch from weather API
        const rainData = {
            volume: 15.2,
            intensity: 'Light Rain',
            lastUpdate: new Date().toLocaleTimeString(),
            icon: 'fa-cloud-rain'
        };
        
        rainInfo.innerHTML = `
            <div style="display: flex; align-items: center; margin-bottom: 10px;">
                <i class="fa ${rainData.icon}" style="color: #2196f3; font-size: 1.5rem; margin-right: 10px;"></i>
                <div>
                    <div style="font-size: 1.3rem; font-weight: bold; color: #1565c0;">${rainData.volume} mm</div>
                    <div style="color: #666; font-size: 0.9rem;">${rainData.intensity}</div>
                </div>
            </div>
            <div style="font-size: 0.8rem; color: #888;">
                <i class="fa fa-clock-o"></i> Updated: ${rainData.lastUpdate}
            </div>
        `;
    }
}

// Function to update current water level display
function updateCurrentWaterLevelDisplay() {
    const currentLevelElement = document.getElementById('currentWaterLevel');
    if (currentLevelElement && currentWaterLevel) {
        const currentLevel = parseFloat(currentWaterLevel.level);
        const currentFeet = parseFloat(currentWaterLevel.feet);
        currentLevelElement.innerHTML = `
            <div style="text-align: center;">
                <div style="font-size: 1.1rem; color: #1565c0; margin-bottom: 5px; margin-top: 20px;">Current Water Level</div>
                <div style="font-size: 1.8rem; font-weight: bold; color: #1565c0;">${currentFeet.toFixed(2)} feet (${currentLevel.toFixed(3)} m)</div>
            </div>
        `;
    }
}

// Function to update all dashboard elements
function updateDashboard() {
    console.log('Updating dashboard...');
    console.log('Water level data:', waterLevelData);
    console.log('Current water level:', currentWaterLevel);
    console.log('Current threshold:', currentWaterLevel.threshold);
    console.log('Current feet:', currentWaterLevel.feet);
    
    try {
        generateChart();
        updateWaterGauge();
        updateWaterLevelInfo();
        updateCurrentWaterLevelDisplay();
        updateWeatherData();
        updateRainData();
        console.log('Dashboard updated successfully');
    } catch (error) {
        console.error('Error updating dashboard:', error);
    }
}

// Function to fetch new data from server
function fetchNewData() {
    fetch('get_water_level_data.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update the global variables with new data
                waterLevelData.length = 0; // Clear existing data
                waterLevelData.push(...data.waterLevelData);
                Object.assign(currentWaterLevel, data.currentWaterLevel);
                
                // Log debug information
                if (data.debug) {
                    console.log('Debug info:', data.debug);
                }
                
                // Update the dashboard with new data
                updateDashboard();
                console.log('Data refreshed successfully');
            } else {
                console.error('Failed to fetch new data:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching new data:', error);
        });
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing dashboard...');
    updateDashboard();
    
    // Auto-refresh every 29 seconds
    setInterval(function() {
        console.log('Auto-refreshing dashboard...');
        fetchNewData();
    }, 29000);
});

// Debug function to check data
function debugData() {
    console.log('=== DEBUG INFO ===');
    console.log('Water level data length:', waterLevelData.length);
    console.log('Current water level:', currentWaterLevel);
    console.log('Chart container exists:', !!document.getElementById('waterLevelChart'));
    console.log('Gauge fill exists:', !!document.getElementById('waterGaugeFill'));
    console.log('Info element exists:', !!document.getElementById('waterLevelInfo'));
    console.log('Weather info exists:', !!document.getElementById('weatherInfo'));
    console.log('Rain info exists:', !!document.getElementById('rainInfo'));
    console.log('Current water level element exists:', !!document.getElementById('currentWaterLevel'));
    console.log('==================');
}

// Call debug function after a short delay
setTimeout(debugData, 1000);
</script>
</body>
</html>