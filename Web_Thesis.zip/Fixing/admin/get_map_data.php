<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

// Include database connection
require_once '../includes/dbconnection.php';

// Function to get current water level
function getCurrentWaterLevel($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            ORDER BY waterLevel_Timestamp DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $meters = floatval($result['waterLevel_Reading_CM']) / 100.0;
            $feet = floatval($result['waterLevel_Reading_Feet']);
            $threshold = $result['waterLevel_Threshold'];
            
            // Convert timestamp to Philippine time
            $dt = new DateTime($result['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila'));
            
            return [
                'meters' => $meters,
                'feet' => $feet,
                'threshold' => $threshold,
                'timestamp' => $dt->format('Y-m-d H:i:s')
            ];
        }
        return ['meters' => 0.899, 'feet' => 2.95, 'threshold' => 'safe', 'timestamp' => date('Y-m-d H:i:s')]; // Default fallback
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['meters' => 0.899, 'feet' => 2.95, 'threshold' => 'safe', 'timestamp' => date('Y-m-d H:i:s')];
    }
}

// Function to determine danger level based on water level threshold from database
function getDangerLevel($waterLevelData) {
    $threshold = $waterLevelData['threshold'] ? strtolower($waterLevelData['threshold']) : 'normal';
    
    if ($threshold === 'danger') {
        return 'danger';
    } elseif ($threshold === 'warning') {
        return 'caution';
    } else {
        return 'safe';
    }
}

// Get data for the response
$currentWaterLevelData = getCurrentWaterLevel($dbh);
$dangerLevel = getDangerLevel($currentWaterLevelData);

// Return JSON response
echo json_encode([
    'success' => true,
    'currentWaterLevel' => $currentWaterLevelData,
    'dangerLevel' => $dangerLevel,
    'timestamp' => date('Y-m-d H:i:s'),
    'debug' => [
        'threshold' => $currentWaterLevelData['threshold'],
        'feet' => $currentWaterLevelData['feet'],
        'meters' => $currentWaterLevelData['meters']
    ]
]);
?> 