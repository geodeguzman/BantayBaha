<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

// Include database connection
require_once '../includes/dbconnection.php';

// Function to get water level data for the last 24 hours
function getWaterLevelData($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        // Fetch all readings from the last 24 hours from the real table
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            WHERE waterLevel_Timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY waterLevel_Timestamp ASC
        ");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group by hour and average, but preserve threshold information
        $hourly = [];
        foreach ($rows as $row) {
            $dt = new DateTime($row['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila')); // Convert to Philippine time
            $hourKey = $dt->format('Y-m-d H:00:00');
            if (!isset($hourly[$hourKey])) {
                $hourly[$hourKey] = [
                    'sum' => 0, 
                    'count' => 0, 
                    'timestamp' => $hourKey,
                    'thresholds' => [],
                    'feet_sum' => 0
                ];
            }
            $hourly[$hourKey]['sum'] += floatval($row['waterLevel_Reading_CM']) / 100.0;
            $hourly[$hourKey]['feet_sum'] += floatval($row['waterLevel_Reading_Feet']);
            $hourly[$hourKey]['count']++;
            $hourly[$hourKey]['thresholds'][] = $row['waterLevel_Threshold'];
        }
        $result = [];
        foreach ($hourly as $hour) {
            $avg = $hour['sum'] / $hour['count'];
            $avgFeet = $hour['feet_sum'] / $hour['count'];
            
            // Determine the most common threshold for this hour
            $thresholdCounts = array_count_values($hour['thresholds']);
            $mostCommonThreshold = array_keys($thresholdCounts, max($thresholdCounts))[0];
            
            $result[] = [
                'water_level_meters' => $avg,
                'water_level_feet' => $avgFeet,
                'threshold' => $mostCommonThreshold,
                'timestamp' => $hour['timestamp'],
                'sensor_id' => 'real'
            ];
        }
        // If more than 24, keep only the last 24
        if (count($result) > 24) {
            $result = array_slice($result, -24);
        }
        return $result;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

// Function to get current water level
function getCurrentWaterLevel($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            ORDER BY waterLevel_Timestamp DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $meters = floatval($result['waterLevel_Reading_CM']) / 100.0;
            $feet = floatval($result['waterLevel_Reading_Feet']);
            $threshold = $result['waterLevel_Threshold'];
            
            // Convert timestamp to Philippine time
            $dt = new DateTime($result['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila'));
            
            return [
                'level' => $meters,
                'feet' => $feet,
                'threshold' => $threshold,
                'timestamp' => $dt->format('Y-m-d H:i:s')
            ];
        }
        return ['level' => 0.899, 'feet' => 2.95, 'threshold' => 'safe', 'timestamp' => date('Y-m-d H:i:s')]; // Default fallback
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['level' => 0.899, 'feet' => 2.95, 'threshold' => 'safe', 'timestamp' => date('Y-m-d H:i:s')];
    }
}

// Get data for the response
$waterLevelData = getWaterLevelData($dbh);
$currentWaterLevel = getCurrentWaterLevel($dbh);

// Return JSON response
echo json_encode([
    'success' => true,
    'waterLevelData' => $waterLevelData,
    'currentWaterLevel' => $currentWaterLevel,
    'timestamp' => date('Y-m-d H:i:s'),
    'debug' => [
        'threshold' => $currentWaterLevel['threshold'],
        'feet' => $currentWaterLevel['feet'],
        'meters' => $currentWaterLevel['level']
    ]
]);
?> 