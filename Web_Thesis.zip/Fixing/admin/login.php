<?php
session_start();
require_once '../includes/dbconnection.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $dbh->prepare('SELECT * FROM admin_users WHERE username = :username LIMIT 1');
    $stmt->execute([':username' => $username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_name'] = $admin['name'];
        header('Location: dashboard.php');
        exit();
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        body { 
            background: linear-gradient(135deg, #87CEEB 0%, #B0E0E6 50%, #ADD8E6 100%);
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        .login-container { 
            max-width: 400px; 
            margin: 80px auto; 
            background: #fff; 
            border-radius: 18px; 
            box-shadow: 0 8px 32px rgba(0,0,0,0.15); 
            padding: 40px 32px; 
            position: relative;
            overflow: hidden;
        }
        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #1565c0, #42a5f5);
        }
        .logo-container {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            width: 120px;
            height: 120px;
            object-fit: contain;
            margin-bottom: 20px;
        }
        .login-title { 
            font-size: 1.8rem; 
            font-weight: 600; 
            color: #1565c0; 
            margin-bottom: 30px; 
            text-align: center; 
        }
        .form-control { 
            border-radius: 12px; 
            border: 2px solid #e3eafc;
            padding: 12px 16px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #1565c0;
            box-shadow: 0 0 0 0.2rem rgba(21, 101, 192, 0.25);
        }
        .btn-primary { 
            border-radius: 12px; 
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            background: linear-gradient(135deg, #1565c0, #1976d2);
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0d47a1, #1565c0);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(21, 101, 192, 0.3);
        }
        .error-msg { 
            color: #e53935; 
            margin-bottom: 16px; 
            text-align: center; 
            background: rgba(229, 57, 53, 0.1);
            padding: 12px;
            border-radius: 8px;
            border: 1px solid rgba(229, 57, 53, 0.3);
        }
        .form-label {
            font-weight: 600;
            color: #1565c0;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="logo-container">
        <img src="../img/Logo.png" alt="Logo" class="logo">
    </div>
    <div class="login-title">Admin Login</div>
    <?php if ($error): ?>
        <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required autofocus>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
</div>
</body>
</html> 