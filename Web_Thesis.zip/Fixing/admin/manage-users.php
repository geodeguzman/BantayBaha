<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}
include('../includes/dbconnection.php');

// Handle Create
if (isset($_POST['create_user'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $age = $_POST['age'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $stmt = $dbh->prepare("INSERT INTO users (name, username, password, age, number, email) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $username, $password, $age, $number, $email]);
    header('Location: manage-users.php');
    exit();
}
// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $dbh->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: manage-users.php');
    exit();
}
// Handle Edit
if (isset($_POST['edit_user'])) {
    $id = intval($_POST['id']);
    $name = $_POST['name'];
    $username = $_POST['username'];
    $age = $_POST['age'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $dbh->prepare("UPDATE users SET name=?, username=?, password=?, age=?, number=?, email=? WHERE id=?");
        $stmt->execute([$name, $username, $password, $age, $number, $email, $id]);
    } else {
        $stmt = $dbh->prepare("UPDATE users SET name=?, username=?, age=?, number=?, email=? WHERE id=?");
        $stmt->execute([$name, $username, $age, $number, $email, $id]);
    }
    header('Location: manage-users.php');
    exit();
}
// Fetch users
$stmt = $dbh->query("SELECT * FROM users ORDER BY id DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users - Thesis Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        body { 
            background: url('../img/bucal.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0; 
            font-family: 'Segoe UI', Arial, sans-serif; 
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
            pointer-events: none;
        }
        .admin-layout { 
            display: flex; 
            min-height: 100vh; 
            position: relative;
            z-index: 1;
        }
        .sidebar { 
            width: 220px; 
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1.5px solid #e3eafc; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            padding: 30px 0 0 0; 
        }
        .sidebar .logo-placeholder { 
            width: 120px; 
            height: 120px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-bottom: 30px; 
        }
        .nav-btn { 
            width: 170px; 
            background: #f7fafd; 
            border: 1.5px solid #e3eafc; 
            border-radius: 12px; 
            padding: 12px 0; 
            margin-bottom: 18px; 
            font-size: 1.1rem; 
            color: #222; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            justify-content: left; 
            font-weight: 500; 
            transition: background 0.2s, color 0.2s; 
        }
        .nav-btn.active, .nav-btn:hover { 
            background: #e3eafc; 
            color: #1565c0; 
        }
        .logout-btn { 
            margin-top: auto; 
            margin-bottom: 30px; 
            background: #fff; 
            color: #e53935; 
            border: 1.5px solid #e53935; 
            border-radius: 12px; 
            padding: 10px 0; 
            width: 170px; 
            font-weight: 600; 
            transition: background 0.2s, color 0.2s; 
        }
        .logout-btn:hover { 
            background: #e53935; 
            color: #fff; 
        }
        .main-content { 
            flex: 1; 
            padding: 30px; 
        }
        .create-user-form, .edit-user-form { 
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 18px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            padding: 28px 32px; 
            margin-bottom: 30px; 
            max-width: 500px; 
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .form-title { 
            font-size: 1.4rem; 
            font-weight: 600; 
            color: #1565c0; 
            margin-bottom: 20px; 
        }
        .form-group { 
            margin-bottom: 16px; 
        }
        .form-group label { 
            font-weight: 600; 
            color: #1565c0; 
            margin-bottom: 6px; 
            display: block; 
        }
        .form-control { 
            border-radius: 12px; 
            border: 1.5px solid #e3eafc; 
            padding: 12px 16px; 
            font-size: 1rem; 
            background: rgba(255, 255, 255, 0.9);
            transition: border-color 0.2s;
        }
        .form-control:focus {
            border-color: #1565c0;
            box-shadow: 0 0 0 3px rgba(21, 101, 192, 0.1);
        }
        .btn-primary { 
            border-radius: 12px; 
            font-weight: 600; 
            padding: 12px 28px; 
            background: #1565c0;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary:hover {
            background: #0d47a1;
            transform: translateY(-1px);
        }
        .btn-cancel { 
            border-radius: 12px; 
            font-weight: 600; 
            padding: 12px 28px; 
            background: #e3eafc; 
            color: #1565c0; 
            border: none; 
            margin-left: 10px; 
            transition: all 0.2s;
        }
        .btn-cancel:hover {
            background: #bbdefb;
            transform: translateY(-1px);
        }
        .users-container {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 18px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            border: 1px solid rgba(255, 255, 255, 0.3);
            overflow: hidden;
        }
        .users-header {
            background: rgba(247, 250, 253, 0.9);
            padding: 20px 24px;
            border-bottom: 1.5px solid #e3eafc;
        }
        .users-header-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .users-header-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #1565c0;
        }
        .users-count {
            background: #1565c0;
            color: #fff;
            padding: 6px 12px;
            border-radius: 12px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        .users-list {
            max-height: 500px;
            overflow-y: auto;
        }
        .user-item {
            display: flex;
            padding: 16px 24px;
            border-bottom: 1px solid rgba(240, 240, 240, 0.5);
            align-items: center;
            gap: 15px;
            transition: background 0.2s;
        }
        .user-item:hover {
            background: rgba(247, 250, 253, 0.5);
        }
        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: #e3eafc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: #2196f3;
            font-weight: bold;
            border: 2px solid #fff;
        }
        .user-info {
            flex: 1;
        }
        .user-name {
            color: #1565c0;
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .user-username {
            color: #000000;
            font-size: 1rem;
        }
        .user-details {
            font-size: 1rem;
            color: #000000;
            display: flex;
            gap: 15px;
            margin-top: 6px;
        }
        .user-actions {
            display: flex;
            gap: 8px;
        }
        .action-btn {
            color: #2196f3;
            font-size: 1.1rem;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.2s;
            text-decoration: none;
        }
        .action-btn:hover {
            background: rgba(33, 150, 243, 0.1);
            color: #1976d2;
        }
        .action-btn.delete {
            color: #e53935;
        }
        .action-btn.delete:hover {
            background: rgba(229, 57, 53, 0.1);
            color: #d32f2f;
        }
        .empty-state {
            padding: 40px 24px;
            text-align: center;
            color: #888;
        }
        .empty-state i {
            font-size: 2.5rem;
            margin-bottom: 10px;
            display: block;
            color: #ccc;
        }
        @media (max-width: 900px) { 
            .main-content { padding: 20px 5px; } 
            .sidebar { width: 60px; padding: 0 10px; } 
            .nav-btn, .logout-btn { width: 60px; padding: 8px 0; font-size: 0.9rem; margin-bottom: 0; margin-right: 8px; justify-content: center; } 
            .sidebar .logo-placeholder { width: 60px; height: 60px; border-radius: 0 0 30px 30px/0 0 30px 30px; font-size: 1rem; margin-bottom: 0; } 
        }
    </style>
</head>
<body>
<script>
window.addEventListener('pageshow', function(event) {
  if (event.persisted) {
    window.location.reload();
  }
});
</script>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="logo-placeholder"><img src="../img/Logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;"></div>
        <div style="margin-bottom: 18px; color: #1565c0; font-weight: 600; text-align: center;">
            <?php if (isset($_SESSION['admin_name'])): ?>
                <div style="font-size: 1.05rem;">Welcome,<br><?php echo htmlspecialchars($_SESSION['admin_name']); ?></div>
            <?php endif; ?>
        </div>
        <a class="nav-btn" href="dashboard.php"><i class="fa fa-columns"></i> Dashboard</a>
        <a class="nav-btn" href="reports.php"><i class="fa fa-file-alt"></i> Reports</a>
        <a class="nav-btn" href="map.php"><i class="fa fa-map"></i> Map</a>
        <a class="nav-btn active" href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a class="nav-btn" href="announcement.php"><i class="fa fa-bullhorn"></i> Create Announcement</a>
        <a class="logout-btn" href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
    </aside>
    <main class="main-content">
        <div style="display: flex; gap: 30px; align-items: flex-start;">
            <!-- Left Column: Create User Form -->
            <div style="flex: 1;">
                <!-- Create User Form -->
                <form class="create-user-form" method="post">
                    <div class="form-title">Create User</div>
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Age</label>
                        <input type="number" name="age" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Number</label>
                        <input type="text" name="number" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <button type="submit" name="create_user" class="btn btn-primary">Create User</button>
                </form>
                
                <!-- Edit User Form (if editing) -->
                <?php if (isset($_GET['edit'])): 
                    $edit_id = intval($_GET['edit']);
                    $stmt = $dbh->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$edit_id]);
                    $edit_user = $stmt->fetch(PDO::FETCH_ASSOC);
                ?>
                <form class="edit-user-form" method="post">
                    <div class="form-title">Edit User</div>
                    <input type="hidden" name="id" value="<?php echo $edit_user['id']; ?>">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_user['name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($edit_user['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Password (leave blank to keep current)</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Age</label>
                        <input type="number" name="age" class="form-control" value="<?php echo htmlspecialchars($edit_user['age']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Number</label>
                        <input type="text" name="number" class="form-control" value="<?php echo htmlspecialchars($edit_user['number']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($edit_user['email']); ?>">
                    </div>
                    <button type="submit" name="edit_user" class="btn btn-primary">Save Changes</button>
                    <a href="manage-users.php" class="btn btn-cancel">Cancel</a>
                </form>
                <?php endif; ?>
            </div>
            
            <!-- Right Column: Users List -->
            <div style="flex: 1;">
                <div class="users-container">
                    <!-- Users Header -->
                    <div class="users-header">
                        <div class="users-header-content">
                            <i class="fa fa-users" style="color:#1565c0;font-size:1.1rem;"></i>
                            <span class="users-header-title">Registered Users</span>
                            <span class="users-count"><?php echo count($users); ?></span>
                        </div>
                    </div>
                    
                    <!-- Users List -->
                    <div class="users-list">
                        <?php if (empty($users)): ?>
                        <div class="empty-state">
                            <i class="fa fa-users"></i>
                            <div>No users registered yet</div>
                        </div>
                        <?php else: ?>
                        <?php foreach ($users as $user): ?>
                        <div class="user-item">
                            <div class="user-avatar">
                                <i class="fa fa-user"></i>
                            </div>
                            <div class="user-info">
                                <div class="user-name"><?php echo htmlspecialchars($user['name']); ?></div>
                                <div class="user-username">@<?php echo htmlspecialchars($user['username']); ?></div>
                                <div class="user-details">
                                    <span><i class="fa fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?></span>
                                    <span><i class="fa fa-phone"></i> <?php echo htmlspecialchars($user['number']); ?></span>
                                    <span><i class="fa fa-birthday-cake"></i> Age: <?php echo htmlspecialchars($user['age']); ?></span>
                                </div>
                            </div>
                            <div class="user-actions">
                                <a href="manage-users.php?edit=<?php echo $user['id']; ?>" class="action-btn" title="Edit">
                                    <i class="fa fa-pencil"></i>
                                </a>
                                <a href="manage-users.php?delete=<?php echo $user['id']; ?>" class="action-btn delete" title="Delete" onclick="return confirm('Delete this user?');">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html> 