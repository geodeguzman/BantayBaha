<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Include database connection
require_once '../includes/dbconnection.php';

// Function to get current water level
function getCurrentWaterLevel($dbh) {
    try {
        // Set timezone to Philippine time
        date_default_timezone_set('Asia/Manila');
        
        $stmt = $dbh->prepare("
            SELECT waterLevel_Reading_CM, waterLevel_Reading_Feet, waterLevel_Threshold, waterLevel_Timestamp 
            FROM waterlevel_informations 
            ORDER BY waterLevel_Timestamp DESC 
            LIMIT 1
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $meters = floatval($result['waterLevel_Reading_CM']) / 100.0;
            $feet = floatval($result['waterLevel_Reading_Feet']);
            $threshold = $result['waterLevel_Threshold'];
            
            // Convert timestamp to Philippine time
            $dt = new DateTime($result['waterLevel_Timestamp']);
            $dt->setTimezone(new DateTimeZone('Asia/Manila'));
            
            return [
                'meters' => $meters,
                'feet' => $feet,
                'threshold' => $threshold,
                'timestamp' => $dt->format('Y-m-d H:i:s')
            ];
        }
        return ['meters' => 0.899, 'feet' => 2.95, 'threshold' => 'normal', 'timestamp' => date('Y-m-d H:i:s')]; // Default fallback
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['meters' => 0.899, 'feet' => 2.95, 'threshold' => 'normal', 'timestamp' => date('Y-m-d H:i:s')];
    }
}

// Function to determine danger level based on water level threshold from database
function getDangerLevel($waterLevelData) {
    $threshold = $waterLevelData['threshold'] ? strtolower($waterLevelData['threshold']) : 'safe';
    
    if ($threshold === 'danger') {
        return 'danger';
    } elseif ($threshold === 'caution') {
        return 'caution';
    } else {
        return 'safe';
    }
}

$currentWaterLevelData = getCurrentWaterLevel($dbh);
$currentWaterLevel = $currentWaterLevelData['meters'];
$dangerLevel = getDangerLevel($currentWaterLevelData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Map - Thesis Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        body { 
            background: url('../img/bucal.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0; 
            font-family: 'Segoe UI', Arial, sans-serif; 
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
            pointer-events: none;
        }
        .admin-layout { 
            display: flex; 
            min-height: 100vh; 
            position: relative;
            z-index: 1;
        }
        .sidebar { 
            width: 220px; 
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1.5px solid #e3eafc; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            padding: 30px 0 0 0; 
        }
        .sidebar .logo-placeholder { 
            width: 120px; 
            height: 120px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-bottom: 30px; 
        }
        .nav-btn { 
            width: 170px; 
            background: #f7fafd; 
            border: 1.5px solid #e3eafc; 
            border-radius: 12px; 
            padding: 12px 0; 
            margin-bottom: 18px; 
            font-size: 1.1rem; 
            color: #222; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            justify-content: left; 
            font-weight: 500; 
            transition: background 0.2s, color 0.2s; 
        }
        .nav-btn.active, .nav-btn:hover { 
            background: #e3eafc; 
            color: #1565c0; 
        }
        .logout-btn { 
            margin-top: auto; 
            margin-bottom: 30px; 
            background: #fff; 
            color: #e53935; 
            border: 1.5px solid #e53935; 
            border-radius: 12px; 
            padding: 10px 0; 
            width: 170px; 
            font-weight: 600; 
            transition: background 0.2s, color 0.2s; 
        }
        .logout-btn:hover { 
            background: #e53935; 
            color: #fff; 
        }
        .main-content { 
            flex: 1; 
            padding: 20px; 
        }

        .map-container { 
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 18px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            padding: 20px; 
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        .map-section { 
            width: 100%; 
            margin-bottom: 20px; 
        }
        .legend-section {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            margin-top: 15px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(255, 255, 255, 0.9);
            padding: 8px 15px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1rem;
        }
        .legend-color {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 3px solid #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .legend-safe { background: #43a047; }
        .legend-caution { background: #fbc02d; }
        .legend-danger { background: #e53935; }
        .legend-sensor { background: #2196f3; }
        
        /* Flood zone styles */
        .flood-zone {
            position: absolute;
            border-radius: 50%;
            opacity: 0.6;
            pointer-events: none;
            z-index: 10;
        }
        .flood-zone.safe { background: rgba(67, 160, 71, 0.3); border: 2px solid #43a047; }
        .flood-zone.caution { background: rgba(251, 192, 45, 0.4); border: 2px solid #fbc02d; }
        .flood-zone.danger { background: rgba(229, 57, 53, 0.5); border: 2px solid #e53935; }
        
        @media (max-width: 900px) { 
            .main-content { padding: 20px 5px; } 
            .sidebar { width: 60px; padding: 0 10px; } 
            .nav-btn, .logout-btn { width: 60px; padding: 8px 0; font-size: 0.9rem; margin-bottom: 0; margin-right: 8px; justify-content: center; } 
            .sidebar .logo-placeholder { width: 60px; height: 60px; border-radius: 0 0 30px 30px/0 0 30px 30px; font-size: 1rem; margin-bottom: 0; } 
            .legend-section { gap: 20px; }
        }
    </style>
</head>
<body>
<script>
window.addEventListener('pageshow', function(event) {
  if (event.persisted) {
    window.location.reload();
  }
});
</script>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="logo-placeholder"><img src="../img/Logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;"></div>
        <div style="margin-bottom: 18px; color: #1565c0; font-weight: 600; text-align: center;">
            <?php if (isset($_SESSION['admin_name'])): ?>
                <div style="font-size: 1.05rem;">Welcome,<br><?php echo htmlspecialchars($_SESSION['admin_name']); ?></div>
            <?php endif; ?>
        </div>
        <a class="nav-btn" href="dashboard.php"><i class="fa fa-columns"></i> Dashboard</a>
        <a class="nav-btn" href="reports.php"><i class="fa fa-file-alt"></i> Reports</a>
        <a class="nav-btn active" href="map.php"><i class="fa fa-map"></i> Map</a>
        <a class="nav-btn" href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a class="nav-btn" href="announcement.php"><i class="fa fa-bullhorn"></i> Create Announcement</a>
        <a class="logout-btn" href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
    </aside>
    <main class="main-content">
        <div class="map-container">
            <div class="map-section">
                <div id="map" style="width: 100%; height: calc(100vh - 120px); border-radius: 18px; box-shadow: 0 2px 8px rgba(44,62,80,0.10);"></div>
            </div>
            
            <!-- Legend Section -->
            <div class="legend-section">
                <div class="legend-item">
                    <div class="legend-color legend-sensor"></div>
                    <span>Sensor Location</span>
                        </div>
                <div class="legend-item">
                    <div class="legend-color legend-danger"></div>
                    <span>Danger Zone (Red)</span>
                    </div>
                <div class="legend-item">
                    <div class="legend-color legend-caution"></div>
                    <span>Warning Zone (Orange)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color legend-safe"></div>
                    <span>Safe Zone (Green)</span>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script>
// Initialize Leaflet map centered on Brgy. Bucal, Calatagan, Batangas
const map = L.map('map').setView([13.862019937691649, 120.66832521062344], 17); // User-provided coordinates and zoom

L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}).addTo(map);

// Add a custom sensor icon marker
const sensorIcon = L.icon({
    iconUrl: '../img/sensor.png', // use local sensor.png
    iconSize: [36, 36], // balanced size for map
    iconAnchor: [18, 36],
    popupAnchor: [0, -36]
});

// Sensor location
const sensorLocation = [13.861281773286077, 120.66598624204374];

// Add sensor marker
L.marker(sensorLocation, { icon: sensorIcon })
    .addTo(map)
    .bindPopup('Ultrasonic Sensor: AJ-SR04M<br>Current Water Level: <?php echo number_format($currentWaterLevelData['meters'], 2); ?>m (<?php echo number_format($currentWaterLevelData['feet'], 2); ?> feet)<br>Threshold: <?php echo ucfirst($currentWaterLevelData['threshold']); ?><br>Status: <?php echo ucfirst($dangerLevel); ?>');

// Define flood prediction zones based on water level
const waterLevel = <?php echo $currentWaterLevelData['meters']; ?>;
const waterLevelFeet = <?php echo $currentWaterLevelData['feet']; ?>;
const threshold = '<?php echo $currentWaterLevelData['threshold']; ?>';
const dangerLevel = '<?php echo $dangerLevel; ?>';

// Calculate zone radii based on water level and danger level
let safeRadius = 0;
let cautionRadius = 0;
let dangerRadius = 0;

// Base sizes that grow with water level
const baseSafeRadius = 50;
const baseCautionRadius = 30;
const baseDangerRadius = 15;

// Scale factor based on water level (higher water level = bigger zones)
const scaleFactor = Math.max(1, waterLevel * 2);

// Use threshold from database to determine zones
if (threshold.toLowerCase() === 'danger') {
    // High water level - all zones visible, scaled by water level
    safeRadius = Math.round(baseSafeRadius * scaleFactor);
    cautionRadius = Math.round(baseCautionRadius * scaleFactor);
    dangerRadius = Math.round(baseDangerRadius * scaleFactor);
} else if (threshold.toLowerCase() === 'caution') {
    // Medium water level - only safe and caution zones visible
    safeRadius = Math.round(baseSafeRadius * scaleFactor);
    cautionRadius = Math.round(baseCautionRadius * scaleFactor);
    dangerRadius = 0; // Not visible
} else {
    // Low water level - no zones visible (whole area is safe)
    safeRadius = 0; // Not visible
    cautionRadius = 0; // Not visible
    dangerRadius = 0; // Not visible
}

// Create flood prediction zones conditionally based on danger level
let safeZone, cautionZone, dangerZone;

// Always create safe zone if it has a radius
if (safeRadius > 0) {
    safeZone = L.circle(sensorLocation, {
        radius: safeRadius,
        color: '#43a047',
        fillColor: '#43a047',
        fillOpacity: 0.3,
        weight: 2
    }).addTo(map);
    safeZone.bindTooltip('Safe Zone (Farthest)<br>Radius: ' + safeRadius + 'm', {permanent: false, direction: 'top'});
}

// Create caution zone only if it has a radius
if (cautionRadius > 0) {
    cautionZone = L.circle(sensorLocation, {
        radius: cautionRadius,
        color: '#fbc02d',
        fillColor: '#fbc02d',
        fillOpacity: 0.4,
        weight: 2
    }).addTo(map);
    cautionZone.bindTooltip('Caution Zone<br>Radius: ' + cautionRadius + 'm', {permanent: false, direction: 'top'});
}

// Create danger zone only if it has a radius
if (dangerRadius > 0) {
    dangerZone = L.circle(sensorLocation, {
        radius: dangerRadius,
        color: '#e53935',
        fillColor: '#e53935',
        fillOpacity: 0.6,
        weight: 3
    }).addTo(map);
    dangerZone.bindTooltip('Danger Zone (Closest)<br>Radius: ' + dangerRadius + 'm', {permanent: false, direction: 'top'});
}

// Function to update map with new data
function updateMapData() {
    fetch('get_map_data.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update sensor popup with new data
                const sensorMarker = L.marker(sensorLocation, { icon: sensorIcon }).addTo(map);
                sensorMarker.bindPopup(`Ultrasonic Sensor: AJ-SR04M<br>Current Water Level: ${data.currentWaterLevel.meters.toFixed(2)}m (${data.currentWaterLevel.feet.toFixed(2)} feet)<br>Threshold: ${data.currentWaterLevel.threshold.charAt(0).toUpperCase() + data.currentWaterLevel.threshold.slice(1)}<br>Status: ${data.dangerLevel.charAt(0).toUpperCase() + data.dangerLevel.slice(1)}`);
                
                // Remove existing zones
                if (safeZone) map.removeLayer(safeZone);
                if (cautionZone) map.removeLayer(cautionZone);
                if (dangerZone) map.removeLayer(dangerZone);
                
                // Calculate new zone radii
                const newWaterLevel = data.currentWaterLevel.meters;
                const newThreshold = data.currentWaterLevel.threshold.toLowerCase();
                const newScaleFactor = Math.max(1, newWaterLevel * 2);
                
                let newSafeRadius = 0;
                let newCautionRadius = 0;
                let newDangerRadius = 0;
                
                if (newThreshold === 'danger') {
                    newSafeRadius = Math.round(baseSafeRadius * newScaleFactor);
                    newCautionRadius = Math.round(baseCautionRadius * newScaleFactor);
                    newDangerRadius = Math.round(baseDangerRadius * newScaleFactor);
                } else if (newThreshold === 'caution') {
                    newSafeRadius = Math.round(baseSafeRadius * newScaleFactor);
                    newCautionRadius = Math.round(baseCautionRadius * newScaleFactor);
                    newDangerRadius = 0;
                } else {
                    newSafeRadius = 0;
                    newCautionRadius = 0;
                    newDangerRadius = 0;
                }
                
                // Create new zones
                if (newSafeRadius > 0) {
                    safeZone = L.circle(sensorLocation, {
                        radius: newSafeRadius,
                        color: '#43a047',
                        fillColor: '#43a047',
                        fillOpacity: 0.3,
                        weight: 2
                    }).addTo(map);
                    safeZone.bindTooltip('Safe Zone (Farthest)<br>Radius: ' + newSafeRadius + 'm', {permanent: false, direction: 'top'});
                }
                
                if (newCautionRadius > 0) {
                    cautionZone = L.circle(sensorLocation, {
                        radius: newCautionRadius,
                        color: '#fbc02d',
                        fillColor: '#fbc02d',
                        fillOpacity: 0.4,
                        weight: 2
                    }).addTo(map);
                    cautionZone.bindTooltip('Caution Zone<br>Radius: ' + newCautionRadius + 'm', {permanent: false, direction: 'top'});
                }
                
                if (newDangerRadius > 0) {
                    dangerZone = L.circle(sensorLocation, {
                        radius: newDangerRadius,
                        color: '#e53935',
                        fillColor: '#e53935',
                        fillOpacity: 0.6,
                        weight: 3
                    }).addTo(map);
                    dangerZone.bindTooltip('Danger Zone (Closest)<br>Radius: ' + newDangerRadius + 'm', {permanent: false, direction: 'top'});
                }
                
                console.log('Map data refreshed successfully');
            } else {
                console.error('Failed to fetch new map data:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching new map data:', error);
        });
}

// Auto-refresh water level every 29 seconds
setInterval(function() {
    console.log('Refreshing map data...');
    updateMapData();
}, 29000);
</script>

</body>
</html> 