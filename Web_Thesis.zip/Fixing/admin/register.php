<?php
session_start();
require_once '../includes/dbconnection.php';

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $name = trim($_POST['name']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if (strlen($username) < 3 || strlen($name) < 2) {
        $error = 'Please enter a valid username and name.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        // Check if username exists
        $stmt = $dbh->prepare('SELECT id FROM admin_users WHERE username = :username');
        $stmt->execute([':username' => $username]);
        if ($stmt->fetch()) {
            $error = 'Username already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $dbh->prepare('INSERT INTO admin_users (username, password_hash, name) VALUES (:username, :hash, :name)');
            $stmt->execute([
                ':username' => $username,
                ':hash' => $hash,
                ':name' => $name
            ]);
            $success = 'Admin profile created! You can now <a href="login.php">login</a>.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Admin Profile</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        body { background: #f7fafd; }
        .register-container { max-width: 420px; margin: 80px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(44,62,80,0.10); padding: 32px 28px; }
        .register-title { font-size: 1.5rem; font-weight: 600; color: #1565c0; margin-bottom: 24px; text-align: center; }
        .form-control { border-radius: 8px; }
        .btn-primary { border-radius: 8px; }
        .error-msg { color: #e53935; margin-bottom: 12px; text-align: center; }
        .success-msg { color: #43a047; margin-bottom: 12px; text-align: center; }
    </style>
</head>
<body>
<div class="register-container">
    <div class="register-title">Create Admin Profile</div>
    <?php if ($error): ?>
        <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php elseif ($success): ?>
        <div class="success-msg"><?php echo $success; ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Create Profile</button>
    </form>
    <div style="margin-top: 18px; text-align: center;">
        <a href="login.php">Back to Login</a>
    </div>
</div>
</body>
</html> 