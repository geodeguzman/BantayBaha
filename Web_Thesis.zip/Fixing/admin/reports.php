<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Include database connection
require_once '../includes/dbconnection.php';

// Function to get reports with user information and images
function getReports($dbh, $status = 'all') {
    try {
        $query = "
            SELECT 
                fr.id,
                fr.location,
                fr.description,
                fr.estimated_damage_cost,
                fr.created_at,
                u.name,
                u.profile_picture,
                COUNT(fri.id) as image_count
            FROM flood_reports fr
            LEFT JOIN users u ON fr.user_id = u.id
            LEFT JOIN flood_report_images fri ON fr.id = fri.report_id
        ";
        
        if ($status === 'pending') {
            $query .= " WHERE fr.status = 'pending'";
        } elseif ($status === 'evaluated') {
            $query .= " WHERE fr.status = 'evaluated'";
        }
        
        $query .= " GROUP BY fr.id ORDER BY fr.created_at DESC";
        
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}



// Function to get images for a specific report
function getReportImages($dbh, $reportId) {
    try {
        $stmt = $dbh->prepare("
            SELECT id, image_url, uploaded_at 
            FROM flood_report_images 
            WHERE report_id = ? 
            ORDER BY uploaded_at ASC
        ");
        $stmt->execute([$reportId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

// Pagination settings
$reportsPerPage = 5; // Show 5 reports per page
$currentPage = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($currentPage - 1) * $reportsPerPage;

// Get total count of reports
function getTotalReportsCount($dbh) {
    try {
        $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return 0;
    }
}

// Get unread reports count (reports created since last visit)
function getUnreadReportsCount($dbh) {
    try {
        // Get the last visit timestamp from session
        $lastVisit = $_SESSION['last_reports_visit'] ?? null;
        
        if ($lastVisit) {
            $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports WHERE created_at > ?");
            $stmt->execute([$lastVisit]);
        } else {
            // If no last visit, show reports from last 24 hours
            $stmt = $dbh->prepare("SELECT COUNT(*) as count FROM flood_reports WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
            $stmt->execute();
        }
        
        return $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return 0;
    }
}

// Get latest report timestamp for auto-refresh
function getLatestReportTimestamp($dbh) {
    try {
        $stmt = $dbh->prepare("SELECT MAX(created_at) as latest FROM flood_reports");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['latest'];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return null;
    }
}

// Get reports data with pagination
function getReportsPaginated($dbh, $limit, $offset) {
    try {
        // First get the paginated report IDs
        $query = "
            SELECT fr.id
            FROM flood_reports fr
            ORDER BY fr.created_at DESC
            LIMIT $limit OFFSET $offset
        ";
        
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $reportIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (empty($reportIds)) {
            return [];
        }
        
        // Then get the full data for those reports
        $placeholders = str_repeat('?,', count($reportIds) - 1) . '?';
        $query = "
            SELECT 
                fr.id,
                fr.location,
                fr.description,
                fr.estimated_damage_cost,
                fr.created_at,
                u.name,
                u.profile_picture,
                COUNT(fri.id) as image_count
            FROM flood_reports fr
            LEFT JOIN users u ON fr.user_id = u.id
            LEFT JOIN flood_report_images fri ON fr.id = fri.report_id
            WHERE fr.id IN ($placeholders)
            GROUP BY fr.id 
            ORDER BY fr.created_at DESC
        ";
        
        $stmt = $dbh->prepare($query);
        $stmt->execute($reportIds);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

$totalReports = getTotalReportsCount($dbh);
$totalPages = ceil($totalReports / $reportsPerPage);
$allReports = getReportsPaginated($dbh, $reportsPerPage, $offset);
$unreadCount = getUnreadReportsCount($dbh);
$latestTimestamp = getLatestReportTimestamp($dbh);

// Mark reports as read by updating the last visit timestamp
$_SESSION['last_reports_visit'] = date('Y-m-d H:i:s');



// Function to format time ago
function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    if ($time < 60) return 'just now';
    if ($time < 3600) return floor($time/60) . 'm';
    if ($time < 86400) return floor($time/3600) . 'h';
    return floor($time/86400) . 'd';
}

// Function to format damage cost
function formatDamageCost($cost) {
    return number_format($cost, 0) . ' Php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports - Thesis Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        body { 
            background: url('../img/bucal.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0; 
            font-family: 'Segoe UI', Arial, sans-serif; 
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(0, 0, 0, 0.4);
            z-index: 0;
            pointer-events: none;
        }
        .admin-layout { 
            display: flex; 
            min-height: 100vh; 
            position: relative;
            z-index: 1;
        }
        .sidebar { 
            width: 220px; 
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1.5px solid #e3eafc; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            padding: 30px 0 0 0; 
        }
        .sidebar .logo-placeholder { 
            width: 120px; 
            height: 120px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            margin-bottom: 30px; 
        }
        .nav-btn { 
            width: 170px; 
            background: #f7fafd; 
            border: 1.5px solid #e3eafc; 
            border-radius: 12px; 
            padding: 12px 0; 
            margin-bottom: 18px; 
            font-size: 1.1rem; 
            color: #222; 
            display: flex; 
            align-items: center; 
            gap: 12px; 
            justify-content: left; 
            font-weight: 500; 
            transition: background 0.2s, color 0.2s; 
        }
        .nav-btn.active, .nav-btn:hover { 
            background: #e3eafc; 
            color: #1565c0; 
        }
        .logout-btn { 
            margin-top: auto; 
            margin-bottom: 30px; 
            background: #fff; 
            color: #e53935; 
            border: 1.5px solid #e53935; 
            border-radius: 12px; 
            padding: 10px 0; 
            width: 170px; 
            font-weight: 600; 
            transition: background 0.2s, color 0.2s; 
        }
        .logout-btn:hover { 
            background: #e53935; 
            color: #fff; 
        }
        .main-content { 
            flex: 1; 
            padding: 40px 30px 30px 30px; 
        }

        .reports-list { 
            margin-top: 20px; 
        }
        .report-card { 
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 18px; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); 
            padding: 28px 32px; 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 32px; 
            margin-bottom: 24px; 
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: transform 0.2s, box-shadow 0.2s;
            opacity: 0;
            transform: translateY(30px);
            animation: fadein 0.8s cubic-bezier(.68,-0.55,.27,1.55) forwards;
        }
        .report-card:nth-child(1) { animation-delay: 0.1s; }
        .report-card:nth-child(2) { animation-delay: 0.2s; }
        .report-card:nth-child(3) { animation-delay: 0.3s; }
        .report-card:nth-child(4) { animation-delay: 0.4s; }
        @keyframes fadein {
            to { opacity: 1; transform: none; }
        }
        .report-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.15);
        }
        .report-avatar { 
            width: 72px; 
            height: 72px; 
            border-radius: 50%; 
            background: #e3eafc; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 1.8rem; 
            color: #2196f3; 
            font-weight: bold;
            flex-shrink: 0;
        }
        .report-info { 
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .report-info strong { 
            color: #f39c12; 
            font-size: 1.6rem; 
            margin-bottom: 8px;
            display: block;
        }
        .report-meta { 
            font-size: 1.2rem; 
            color: #888; 
            margin-bottom: 8px; 
        }
        .report-details { 
            font-size: 1.3rem; 
            color: #222; 
            margin-bottom: 16px;
            line-height: 1.6;
        }
        .report-images {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            min-height: 280px;
        }
        .report-image {
            width: 120px;
            height: 120px;
            border-radius: 16px;
            object-fit: cover;
            cursor: pointer;
            border: 3px solid #e3eafc;
            transition: transform 0.2s, border-color 0.2s;
        }
        .report-image:hover {
            transform: scale(1.05);
            border-color: #2196f3;
        }
        .image-count {
            background: rgba(33, 150, 243, 0.9);
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 1.1rem;
            margin-left: 8px;
            font-weight: 600;
        }
        
        /* Modal styles for image viewer */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
        }
        .modal-content {
            margin: auto;
            display: block;
            width: 90%;
            max-width: 800px;
            max-height: 90%;
            object-fit: contain;
        }
        .close {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #bbb;
        }
        .no-reports {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 1.1rem;
        }
        
        /* Pagination styles */
        .pagination-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
            padding: 20px;
        }
        .pagination-btn {
            background: rgba(255, 255, 255, 0.8);
            border: 2px solid #e3eafc;
            border-radius: 12px;
            padding: 12px 20px;
            font-size: 1.1rem;
            color: #1565c0;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            font-weight: 600;
        }
        .pagination-btn:hover {
            background: #e3eafc;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(33, 150, 243, 0.2);
        }
        .pagination-btn.active {
            background: #1565c0;
            color: white;
            border-color: #1565c0;
        }
        .pagination-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        .pagination-info {
            background: rgba(255, 255, 255, 0.9);
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 1.1rem;
            color: #1565c0;
            font-weight: 600;
        }
        
        /* Notification badge styles */
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #e53935;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        @media (max-width: 900px) { 
            .main-content { padding: 20px 5px; } 
            .sidebar { width: 60px; padding: 0 10px; } 
            .nav-btn, .logout-btn { width: 60px; padding: 8px 0; font-size: 0.9rem; margin-bottom: 0; margin-right: 8px; justify-content: center; } 
            .sidebar .logo-placeholder { width: 60px; height: 60px; border-radius: 0 0 30px 30px/0 0 30px 30px; font-size: 1rem; margin-bottom: 0; } 
        }
    </style>
    <script>
        function openImageModal(imageUrl) {
            const modal = document.getElementById('imageModal');
            const modalImg = document.getElementById('modalImage');
            modal.style.display = "block";
            modalImg.src = imageUrl;
        }
        
        function closeImageModal() {
            document.getElementById('imageModal').style.display = "none";
        }
        
        // Close modal when clicking outside the image
        window.onclick = function(event) {
            const modal = document.getElementById('imageModal');
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
    <script>
    window.addEventListener('pageshow', function(event) {
      if (event.persisted) {
        window.location.reload();
      }
    });
    
    // Auto-refresh functionality
    let lastReportTimestamp = '<?php echo $latestTimestamp; ?>';
    let isFirstLoad = true;
    
    // Create notification sound
    function playNotificationSound() {
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
        audio.volume = 0.3;
        audio.play().catch(e => console.log('Audio play failed:', e));
    }
    
    // Check for new reports
    function checkForNewReports() {
        fetch('check_new_reports.php?last_timestamp=' + encodeURIComponent(lastReportTimestamp))
            .then(response => response.json())
            .then(data => {
                if (data.hasNewReports && !isFirstLoad) {
                    // Play notification sound
                    playNotificationSound();
                    
                    // Update notification badge
                    const badge = document.querySelector('.notification-badge');
                    if (badge) {
                        badge.textContent = data.unreadCount;
                    } else if (data.unreadCount > 0) {
                        // Create new badge if it doesn't exist
                        const reportsLink = document.querySelector('a[href="reports.php"]');
                        if (reportsLink) {
                            const newBadge = document.createElement('span');
                            newBadge.className = 'notification-badge';
                            newBadge.textContent = data.unreadCount;
                            reportsLink.appendChild(newBadge);
                        }
                    }
                    
                    // Show notification
                    showNotification('New flood report received!');
                }
                
                if (data.latestTimestamp) {
                    lastReportTimestamp = data.latestTimestamp;
                }
                
                isFirstLoad = false;
            })
            .catch(error => console.log('Error checking for new reports:', error));
    }
    
    // Reset notification badge when page loads (reports are now "read")
    function resetNotificationBadge() {
        const badge = document.querySelector('.notification-badge');
        if (badge) {
            badge.remove();
        }
    }
    
    // Call reset function when page loads
    resetNotificationBadge();
    
    // Show browser notification
    function showNotification(message) {
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('Flood Monitoring System', {
                body: message,
                icon: '../img/Logo.png'
            });
        }
    }
    
    // Request notification permission on page load
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
    
    // Check for new reports every 30 seconds
    setInterval(checkForNewReports, 30000);
    
    // Also check when page becomes visible
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            checkForNewReports();
      }
    });
    </script>
</head>
<body>
<div class="admin-layout">
    <aside class="sidebar">
        <div class="logo-placeholder"><img src="../img/Logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;"></div>
        <div style="margin-bottom: 18px; color: #1565c0; font-weight: 600; text-align: center;">
            <?php if (isset($_SESSION['admin_name'])): ?>
                <div style="font-size: 1.05rem;">Welcome,<br><?php echo htmlspecialchars($_SESSION['admin_name']); ?></div>
            <?php endif; ?>
        </div>
        <a class="nav-btn" href="dashboard.php"><i class="fa fa-columns"></i> Dashboard</a>
        <a class="nav-btn active" href="reports.php" style="position: relative;">
            <i class="fa fa-file-alt"></i> Reports
            <?php if ($unreadCount > 0): ?>
                <span class="notification-badge"><?php echo $unreadCount; ?></span>
            <?php endif; ?>
        </a>
        <a class="nav-btn" href="map.php"><i class="fa fa-map"></i> Map</a>
        <a class="nav-btn" href="manage-users.php"><i class="fa fa-users"></i> Manage Users</a>
        <a class="nav-btn" href="announcement.php"><i class="fa fa-bullhorn"></i> Create Announcement</a>
        <a class="logout-btn" href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a>
    </aside>
    <main class="main-content">
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1565c0; font-size: 2rem; font-weight: 600; margin-bottom: 10px;">Flood Reports</h2>
            <p style="color: #000000; font-size: 1.1rem; font-weight: 600; background: rgba(255, 255, 255, 0.9); padding: 10px 15px; border-radius: 8px; display: inline-block;">Total Reports: <?php echo $totalReports; ?> | Showing <?php echo count($allReports); ?> reports (Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?>)</p>
        </div>
        <div class="reports-list">
            
            <div class="tab-content" id="all-content">
                <?php if (empty($allReports)): ?>
                    <div class="no-reports">No reports found. Check the debug information above.</div>
                <?php else: ?>
                    <?php foreach ($allReports as $report): ?>
                <div class="report-card">
                            <!-- Left side: Text content -->
                    <div class="report-info">
                                <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 16px;">
                                    <div class="report-avatar">
                                        <?php if (!empty($report['profile_picture'])): ?>
                                            <img src="<?php echo htmlspecialchars($report['profile_picture']); ?>" alt="avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">
                                        <?php else: ?>
                                            <i class="fa fa-user"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <strong><?php echo htmlspecialchars($report['name']); ?></strong> 
                                        <span class="report-meta">• <?php echo timeAgo($report['created_at']); ?></span>
                                        <?php if ($report['image_count'] > 0): ?>
                                            <span class="image-count"><?php echo $report['image_count']; ?> image<?php echo $report['image_count'] > 1 ? 's' : ''; ?></span>
                                        <?php endif; ?>
                    </div>
                </div>
                        <span class="report-details">
                                    <b>Location:</b> <?php echo htmlspecialchars($report['location']); ?><br>
                                    <b>Description:</b> <?php echo htmlspecialchars($report['description']); ?><br>
                                    <b>Estimated Cost:</b> <?php echo formatDamageCost($report['estimated_damage_cost']); ?>
                        </span>
                    </div>
                            
                            <!-- Right side: Images -->
                            <div class="report-images">
                                <?php 
                                $images = getReportImages($dbh, $report['id']);
                                if (!empty($images)): ?>
                                    <?php foreach (array_slice($images, 0, 4) as $image): ?>
                                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>" 
                                             alt="Report Image" 
                                             class="report-image"
                                             onclick="openImageModal('<?php echo htmlspecialchars($image['image_url']); ?>')"
                                             title="Click to view full size">
                                    <?php endforeach; ?>
                                    <?php if (count($images) > 4): ?>
                                        <div style="width: 120px; height: 120px; background: #e3eafc; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #2196f3; font-weight: bold; border: 3px solid #e3eafc; font-size: 1.2rem;">
                                            +<?php echo count($images) - 4; ?>
                </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #999; font-style: italic;">
                                        No images available
            </div>
                                <?php endif; ?>
                    </div>
                </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <!-- Pagination Controls -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination-container">
                        <?php if ($currentPage > 1): ?>
                            <a href="?page=<?php echo $currentPage - 1; ?>" class="pagination-btn">← Previous</a>
                        <?php else: ?>
                            <span class="pagination-btn" style="opacity: 0.5; cursor: not-allowed;">← Previous</span>
                        <?php endif; ?>
                        
                        <div class="pagination-info">
                            Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?>
            </div>
                        
                        <?php if ($currentPage < $totalPages): ?>
                            <a href="?page=<?php echo $currentPage + 1; ?>" class="pagination-btn">Next →</a>
                        <?php else: ?>
                            <span class="pagination-btn" style="opacity: 0.5; cursor: not-allowed;">Next →</span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Page Numbers -->
                    <div class="pagination-container" style="margin-top: 10px;">
                        <?php
                        $startPage = max(1, $currentPage - 2);
                        $endPage = min($totalPages, $currentPage + 2);
                        
                        if ($startPage > 1): ?>
                            <a href="?page=1" class="pagination-btn">1</a>
                            <?php if ($startPage > 2): ?>
                                <span style="color: #666; padding: 0 10px;">...</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                            <a href="?page=<?php echo $i; ?>" class="pagination-btn <?php echo $i == $currentPage ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($endPage < $totalPages): ?>
                            <?php if ($endPage < $totalPages - 1): ?>
                                <span style="color: #666; padding: 0 10px;">...</span>
                            <?php endif; ?>
                            <a href="?page=<?php echo $totalPages; ?>" class="pagination-btn"><?php echo $totalPages; ?></a>
                        <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- Image Modal -->
<div id="imageModal" class="modal">
    <span class="close" onclick="closeImageModal()">&times;</span>
    <img class="modal-content" id="modalImage">
</div>
</body>
</html> 