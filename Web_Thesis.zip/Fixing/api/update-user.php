<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$conn = new mysqli("localhost", "root", "", "thesis_db");
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

$id = $data["id"] ?? null;
if (!$id) {
    echo json_encode(["success" => false, "message" => "User ID required"]);
    exit();
}

// Fetch current user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$current = $stmt->get_result()->fetch_assoc();

if (!$current) {
    echo json_encode(["success" => false, "message" => "User not found"]);
    exit();
}

// Use new value if provided, otherwise keep current
$name = array_key_exists("name", $data) ? $data["name"] : $current['name'];
$username = array_key_exists("username", $data) ? $data["username"] : $current['username'];
$age = array_key_exists("age", $data) ? $data["age"] : $current['age'];
$number = array_key_exists("number", $data) ? $data["number"] : $current['number'];
$email = array_key_exists("email", $data) ? $data["email"] : $current['email'];
$password = $data["password"] ?? null;

if ($password) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, password=?, age=?, number=?, email=? WHERE id=?");
    $stmt->bind_param("ssssssi", $name, $username, $hashed_password, $age, $number, $email, $id);
} else {
    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, age=?, number=?, email=? WHERE id=?");
    $stmt->bind_param("sssssi", $name, $username, $age, $number, $email, $id);
}

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Update failed"]);
}
?>