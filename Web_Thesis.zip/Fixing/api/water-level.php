<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../includes/dbconnection.php';

// Function to validate water level data
function validateWaterLevel($level) {
    return is_numeric($level) && $level >= 0 && $level <= 10; // Max 10 meters
}

// Function to validate sensor ID
function validateSensorId($sensorId) {
    return !empty($sensorId) && strlen($sensorId) <= 50;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get JSON input
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Invalid JSON input');
        }
        
        // Validate required fields
        if (!isset($input['water_level_meters'])) {
            throw new Exception('water_level_meters is required');
        }
        
        if (!validateWaterLevel($input['water_level_meters'])) {
            throw new Exception('Invalid water level value (must be 0-10 meters)');
        }
        
        // Optional sensor ID
        $sensorId = isset($input['sensor_id']) ? $input['sensor_id'] : 'sensor_001';
        if (!validateSensorId($sensorId)) {
            throw new Exception('Invalid sensor ID');
        }
        
        // Insert data into database
        $stmt = $dbh->prepare("
            INSERT INTO water_level_data (water_level_meters, sensor_id, timestamp) 
            VALUES (:water_level, :sensor_id, NOW())
        ");
        
        $stmt->execute([
            ':water_level' => $input['water_level_meters'],
            ':sensor_id' => $sensorId
        ]);
        
        $response = [
            'success' => true,
            'message' => 'Water level data recorded successfully',
            'data' => [
                'water_level_meters' => $input['water_level_meters'],
                'sensor_id' => $sensorId,
                'timestamp' => date('Y-m-d H:i:s'),
                'id' => $dbh->lastInsertId()
            ]
        ];
        
        http_response_code(201);
        echo json_encode($response);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get recent water level data
        $limit = isset($_GET['limit']) ? min((int)$_GET['limit'], 100) : 24; // Default 24, max 100
        
        $stmt = $dbh->prepare("
            SELECT id, water_level_meters, sensor_id, timestamp 
            FROM water_level_data 
            ORDER BY timestamp DESC 
            LIMIT :limit
        ");
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $response = [
            'success' => true,
            'data' => $data,
            'count' => count($data)
        ];
        
        echo json_encode($response);
        
    } else {
        throw new Exception('Method not allowed');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?> 