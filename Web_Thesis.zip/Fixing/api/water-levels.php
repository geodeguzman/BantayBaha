<?php
require_once 'config.php';

try {
    // Get water level data with correct column names
    $stmt = $pdo->prepare("SELECT * FROM waterlevel_informations ORDER BY created_at DESC LIMIT 100");
    $stmt->execute();
    $waterLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get latest water level
    $stmt = $pdo->prepare("SELECT * FROM waterlevel_informations ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    $latestWaterLevel = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Transform data to match mobile app expectations
    $transformedWaterLevels = array_map(function($level) {
        return [
            'id' => $level['id'] ?? null,
            'water_level' => $level['waterLevel_Reading_CM'] ?? null,
            'water_level_feet' => $level['waterLevel_Reading_Feet'] ?? null,
            'threshold' => $level['waterLevel_Threshold'] ?? null,
            'created_at' => $level['created_at'] ?? null,
            'updated_at' => $level['updated_at'] ?? null
        ];
    }, $waterLevels);
    
    $transformedLatest = $latestWaterLevel ? [
        'id' => $latestWaterLevel['id'] ?? null,
        'water_level' => $latestWaterLevel['waterLevel_Reading_CM'] ?? null,
        'water_level_feet' => $latestWaterLevel['waterLevel_Reading_Feet'] ?? null,
        'threshold' => $latestWaterLevel['waterLevel_Threshold'] ?? null,
        'created_at' => $latestWaterLevel['created_at'] ?? null,
        'updated_at' => $latestWaterLevel['updated_at'] ?? null
    ] : null;
    
    $response = [
        'success' => true,
        'data' => [
            'water_levels' => $transformedWaterLevels,
            'latest' => $transformedLatest
        ]
    ];
    
    echo json_encode($response);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?> 