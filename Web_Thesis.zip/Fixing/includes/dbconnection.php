<?php
$host = "mysql.hostinger.com";
$username = "u285955690_BantayBaha";
$password = "BantayBaha123";
$database = "u285955690_thesis_db";

try {
    $dbh = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?> 