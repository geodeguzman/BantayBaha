    <!-- Footer Area Start -->
    <footer class="footer-area" style="background-color: #2c3e50; color: #ecf0f1;">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-widget">
                        <h3>About Thesis</h3>
                        <p>Your thesis project description goes here. This is a placeholder for your research or project information.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="footer-widget">
                        <h3>Quick Links</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="footer-widget">
                        <h3>Contact Info</h3>
                        <ul>
                            <li><i class="fa fa-phone"></i> +1 234 567 8900</li>
                            <li><i class="fa fa-envelope"></i> info@thesis.com</li>
                            <li><i class="fa fa-map-marker"></i> Your Address Here</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom" style="background-color: #34495e;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>&copy; 2024 Thesis Project. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- JavaScript Files -->
    <script src="js/vendor/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script src="js/change-text.js"></script>
    <script src="js/jquery.lettering.js"></script>
    <script src="js/jquery.textillate.js"></script>
    <script src="js/jquery.mb.YTPlayer.min.js"></script>
    <script src="js/ajax-mail.js"></script>
</body>
</html> 