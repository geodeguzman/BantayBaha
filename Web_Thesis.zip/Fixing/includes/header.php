<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thesis Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSS Files -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/icofont.css">
    <link rel="stylesheet" href="css/change-text.css">
    <link rel="stylesheet" href="css/jquery.mb.YTPlayer.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="style.css">
    
    <!-- Modernizr JS -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
    <!-- Animated SVG Wave Background -->
    <style>
    .animated-wave-bg {
      position: fixed;
      top: 0; left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 0;
      pointer-events: none;
      overflow: hidden;
    }
    .animated-wave-bg-inner {
      position: absolute;
      width: 200vw;
      height: 50vh;
      top: 0;
      left: 0;
      display: flex;
      flex-direction: row;
      animation: waveMove 16s linear infinite;
    }
    @keyframes waveMove {
      0% { transform: translateX(0); }
      100% { transform: translateX(-50vw); }
    }
    </style>
    <div class="animated-wave-bg">
      <div class="animated-wave-bg-inner">
        <svg height="100%" width="100vw" viewBox="0 0 1920 320" preserveAspectRatio="none" style="display:block;">
          <path d="M0 160 Q 960 220, 1920 160 T 1920 160 V320 H0 Z" fill="#2196f3" opacity="0.7"/>
          <path d="M0 180 Q 960 240, 1920 180 T 1920 180 V320 H0 Z" fill="#1976d2" opacity="0.5"/>
        </svg>
        <svg height="100%" width="100vw" viewBox="0 0 1920 320" preserveAspectRatio="none" style="display:block;">
          <path d="M0 160 Q 960 220, 1920 160 T 1920 160 V320 H0 Z" fill="#2196f3" opacity="0.7"/>
          <path d="M0 180 Q 960 240, 1920 180 T 1920 180 V320 H0 Z" fill="#1976d2" opacity="0.5"/>
        </svg>
      </div>
    </div>
    <!-- Header Area Start -->
    <header id="sticker">
        <div class="header-top" style="background-color: #2c3e50;">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <div class="welcome-msg">
                            <ul>
                                <li><p><span style="color: #ecf0f1;">Contact: </span>+1 234 567 8900</p></li>
                                <li><p><span style="color: #ecf0f1;">Email: </span>info@thesis.com</p></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="header-top-menu">
                            <div class="top-social">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook" style="color: #ecf0f1;"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter" style="color: #ecf0f1;"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram" style="color: #ecf0f1;"></i></a></li>
                                    <li><a href="admin/login.php" style="color: #ecf0f1;">Admin</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Menu Area Start -->
        <div class="main-menu-area" style="background-color: #34495e;">
            <div class="container">
                <div class="menu-position">
                    <div class="row">
                        <div class="col-md-3 col-sm-2">
                            <div class="logo">
                                <a href="index.php">
                                    <h1 style="color: #ecf0f1;">THESIS</h1>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-9 col-sm-10 static">
                            <div class="main-menu">
                                <nav>
                                    <ul>
                                        <li><a href="index.php" class="menu-link">Home</a></li>
                                        <li><a href="about.php" class="menu-link">About</a></li>
                                        <li><a href="services.php" class="menu-link">Services</a></li>
                                        <li><a href="contact.php" class="menu-link">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->
</body>
</html> 