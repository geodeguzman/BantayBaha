<?php
header("Location: admin/login.php");
exit();
?>
